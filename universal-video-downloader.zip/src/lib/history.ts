export interface HistoryItem {
  id: string;
  title: string;
  thumbnail: string;
  url: string;
  uploader: string;
  quality: string;
  ext: string;
  at: number;
  favorite?: boolean;
}

const KEY = "uvd-history";

export function loadHistory(): HistoryItem[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(window.localStorage.getItem(KEY) ?? "[]") as HistoryItem[];
  } catch {
    return [];
  }
}

export function saveHistory(items: HistoryItem[]) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(KEY, JSON.stringify(items.slice(0, 50)));
}

export function addToHistory(item: HistoryItem) {
  const all = loadHistory();
  const next = [item, ...all.filter((i) => !(i.url === item.url && i.quality === item.quality))];
  saveHistory(next);
  return next;
}

export function toggleFavorite(id: string) {
  const all = loadHistory().map((i) => (i.id === id ? { ...i, favorite: !i.favorite } : i));
  saveHistory(all);
  return all;
}

export function removeFromHistory(id: string) {
  const all = loadHistory().filter((i) => i.id !== id);
  saveHistory(all);
  return all;
}

export function clearHistory() {
  saveHistory([]);
}
