export interface VideoFormat {
  format_id: string;
  ext: string;
  quality: string; // e.g. "1080p", "audio"
  filesize?: number;
  type: "video" | "audio";
  note?: string;
}

export interface VideoInfo {
  id: string;
  title: string;
  thumbnail: string;
  duration: number; // seconds
  uploader: string;
  webpage_url: string;
  formats: VideoFormat[];
}

const API_BASE = (import.meta.env.VITE_API_URL as string | undefined)?.replace(/\/$/, "") ?? "";

export function isApiConfigured() {
  return API_BASE.length > 0;
}

export async function fetchVideoInfo(url: string): Promise<VideoInfo> {
  if (!API_BASE) throw new Error("Downloader API not configured. Set VITE_API_URL to your backend URL.");
  const res = await fetch(`${API_BASE}/api/info`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url }),
  });
  if (!res.ok) {
    const msg = await res.text().catch(() => "");
    throw new Error(msg || `Request failed (${res.status})`);
  }
  return (await res.json()) as VideoInfo;
}

export function downloadUrlFor(url: string, formatId: string) {
  const params = new URLSearchParams({ url, format: formatId });
  return `${API_BASE}/api/download?${params.toString()}`;
}
