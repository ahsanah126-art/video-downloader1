import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { FiChevronDown } from "react-icons/fi";
import { motion, AnimatePresence } from "framer-motion";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { BackgroundBlobs } from "@/components/BackgroundBlobs";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ — Universal Video Downloader" },
      { name: "description", content: "Answers to common questions about downloading videos safely and quickly." },
      { property: "og:title", content: "FAQ — Universal Video Downloader" },
      { property: "og:description", content: "How the downloader works, which sites are supported, and more." },
    ],
  }),
  component: FaqPage,
});

const FAQS = [
  {
    q: "How does it work?",
    a: "Paste a video URL from a supported platform. We fetch the available formats and let you pick the quality you want. When you press download, the file streams directly to your device.",
  },
  {
    q: "Which websites are supported?",
    a: "YouTube, TikTok, Instagram (public), X/Twitter, Facebook, Vimeo, Dailymotion, Twitch clips and Reddit videos — plus many more via yt-dlp on the backend.",
  },
  {
    q: "Is it free?",
    a: "Yes. No account, no signup, no watermarks. You only need a working internet connection.",
  },
  {
    q: "Is downloading safe?",
    a: "We never store your videos or history on our servers — your recent downloads live only in your browser. Always respect the copyright and terms of the source platform.",
  },
  {
    q: "Why is my video unavailable?",
    a: "The video might be private, age-restricted, region-locked, or the platform may have changed. Try a different URL or check the source is publicly viewable.",
  },
];

function FaqPage() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <div className="relative min-h-screen">
      <BackgroundBlobs />
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-4 py-16 sm:px-6 sm:py-24">
        <div className="text-center">
          <h1 className="font-display text-4xl font-semibold sm:text-5xl">Frequently asked</h1>
          <p className="mt-3 text-muted-foreground">Everything you might want to know.</p>
        </div>

        <ul className="mt-12 space-y-3">
          {FAQS.map((item, i) => {
            const isOpen = open === i;
            return (
              <li key={item.q} className="glass overflow-hidden rounded-2xl">
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
                >
                  <span className="font-medium">{item.q}</span>
                  <FiChevronDown
                    className={cn(
                      "h-5 w-5 shrink-0 text-muted-foreground transition-transform",
                      isOpen && "rotate-180",
                    )}
                  />
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden"
                    >
                      <p className="px-5 pb-5 text-sm text-muted-foreground">{item.a}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </li>
            );
          })}
        </ul>
      </main>
      <SiteFooter />
    </div>
  );
}
