import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  FiZap,
  FiShield,
  FiLayers,
  FiMusic,
  FiVideo,
  FiGlobe,
} from "react-icons/fi";
import { SiYoutube, SiTiktok, SiInstagram, SiFacebook, SiX, SiVimeo, SiDailymotion, SiTwitch, SiReddit } from "react-icons/si";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { BackgroundBlobs } from "@/components/BackgroundBlobs";
import { DownloaderApp } from "@/components/DownloaderApp";

export const Route = createFileRoute("/")({
  component: HomePage,
});

const SITES = [
  { icon: SiYoutube, name: "YouTube" },
  { icon: SiTiktok, name: "TikTok" },
  { icon: SiInstagram, name: "Instagram" },
  { icon: SiX, name: "X / Twitter" },
  { icon: SiFacebook, name: "Facebook" },
  { icon: SiVimeo, name: "Vimeo" },
  { icon: SiDailymotion, name: "Dailymotion" },
  { icon: SiTwitch, name: "Twitch" },
  { icon: SiReddit, name: "Reddit" },
];

const FEATURES = [
  {
    icon: FiZap,
    title: "Blazing fast",
    body: "Direct-to-device streams with no waiting rooms or artificial queues.",
  },
  {
    icon: FiLayers,
    title: "Every quality",
    body: "From 360p to 4K. Pick the resolution and format that fits your device.",
  },
  {
    icon: FiMusic,
    title: "Audio extraction",
    body: "One click to grab just the audio as MP3 or M4A — perfect for podcasts.",
  },
  {
    icon: FiShield,
    title: "Private by design",
    body: "No account, no tracking. Your history lives only in your browser.",
  },
  {
    icon: FiGlobe,
    title: "9+ platforms",
    body: "YouTube, TikTok, Instagram, X, Vimeo, Facebook, Twitch and more.",
  },
  {
    icon: FiVideo,
    title: "MP4 & more",
    body: "MP4, WEBM, MP3, M4A — universally compatible with any player.",
  },
];

function HomePage() {
  return (
    <div className="relative min-h-screen">
      <BackgroundBlobs />
      <SiteHeader />

      <main className="mx-auto max-w-6xl px-4 sm:px-6">
        {/* Hero */}
        <section className="pb-8 pt-16 text-center sm:pt-24">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full border border-border/70 bg-card/60 px-3 py-1 text-xs font-medium text-muted-foreground backdrop-blur"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-success" />
            Free · No account · No watermarks
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.05 }}
            className="mx-auto max-w-3xl font-display text-5xl font-bold leading-[1.05] tracking-tight sm:text-6xl md:text-7xl"
          >
            Download videos <br className="hidden sm:block" />
            in <span className="gradient-text">seconds</span>.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="mx-auto mt-5 max-w-xl text-base text-muted-foreground sm:text-lg"
          >
            Paste a link from your favorite platform and grab it in the quality
            and format you want. Simple as that.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.25 }}
            className="mt-10"
          >
            <DownloaderApp />
          </motion.div>
        </section>

        {/* Supported sites */}
        <section className="py-10">
          <p className="text-center text-xs font-medium uppercase tracking-widest text-muted-foreground">
            Works with your favorite platforms
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-x-8 gap-y-5">
            {SITES.map(({ icon: Icon, name }) => (
              <div
                key={name}
                className="flex items-center gap-2 text-muted-foreground transition-colors hover:text-foreground"
                title={name}
              >
                <Icon className="h-6 w-6" />
                <span className="text-sm font-medium">{name}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Features */}
        <section id="features" className="py-16 sm:py-24">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="font-display text-3xl font-semibold sm:text-4xl">
              Built for the way you actually save videos
            </h2>
            <p className="mt-3 text-muted-foreground">
              Every detail obsessed over so the workflow disappears.
            </p>
          </div>
          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map(({ icon: Icon, title, body }, i) => (
              <motion.div
                key={title}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.4, delay: i * 0.05 }}
                className="glass rounded-3xl p-6 transition-all hover:-translate-y-0.5 hover:shadow-glow"
              >
                <div className="grid h-11 w-11 place-items-center rounded-2xl gradient-primary shadow-glow">
                  <Icon className="h-5 w-5 text-white" />
                </div>
                <h3 className="mt-4 text-lg font-semibold">{title}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{body}</p>
              </motion.div>
            ))}
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
