import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  FiLink,
  FiClipboard,
  FiDownload,
  FiPlay,
  FiMusic,
  FiVideo,
  FiCheck,
  FiAlertCircle,
  FiStar,
  FiTrash2,
  FiSearch,
  FiCopy,
} from "react-icons/fi";
import { toast } from "sonner";
import { fetchVideoInfo, downloadUrlFor, isApiConfigured, type VideoInfo, type VideoFormat } from "@/lib/api";
import { isValidUrl, formatDuration, formatBytes } from "@/lib/format";
import {
  addToHistory,
  clearHistory,
  loadHistory,
  removeFromHistory,
  toggleFavorite,
  type HistoryItem,
} from "@/lib/history";
import { cn } from "@/lib/utils";

type DownloadState = "idle" | "processing" | "done" | "error";

export function DownloaderApp() {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [info, setInfo] = useState<VideoInfo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [dlState, setDlState] = useState<DownloadState>("idle");
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [search, setSearch] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => setHistory(loadHistory()), []);

  // Keyboard: cmd/ctrl+v anywhere focuses input
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "v") {
        if (document.activeElement !== inputRef.current) inputRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setUrl(text.trim());
        toast.success("Pasted from clipboard");
      }
    } catch {
      toast.error("Clipboard access blocked");
    }
  };

  const handleFetch = async (targetUrl?: string) => {
    const u = (targetUrl ?? url).trim();
    if (!isValidUrl(u)) {
      setError("Please enter a valid video URL.");
      toast.error("Invalid URL");
      return;
    }
    setError(null);
    setInfo(null);
    setSelected(null);
    setLoading(true);
    try {
      const data = await fetchVideoInfo(u);
      setInfo(data);
      const preferred =
        data.formats.find((f) => f.quality === "1080p") ??
        data.formats.find((f) => f.type === "video") ??
        data.formats[0];
      setSelected(preferred?.format_id ?? null);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Something went wrong";
      setError(msg);
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  const startDownload = async () => {
    if (!info || !selected) return;
    const fmt = info.formats.find((f) => f.format_id === selected);
    if (!fmt) return;

    setDlState("processing");
    setProgress(0);
    // Simulated progress while browser downloads via the backend stream.
    const timer = window.setInterval(() => {
      setProgress((p) => {
        const next = p + Math.random() * 12;
        return next >= 92 ? 92 : next;
      });
    }, 350);

    try {
      const href = downloadUrlFor(info.webpage_url, fmt.format_id);
      // Trigger native download
      const a = document.createElement("a");
      a.href = href;
      a.rel = "noopener";
      a.download = "";
      document.body.appendChild(a);
      a.click();
      a.remove();

      window.setTimeout(() => {
        window.clearInterval(timer);
        setProgress(100);
        setDlState("done");
        toast.success("Download started");
        const next = addToHistory({
          id: `${info.id}-${fmt.format_id}-${Date.now()}`,
          title: info.title,
          thumbnail: info.thumbnail,
          url: info.webpage_url,
          uploader: info.uploader,
          quality: fmt.quality,
          ext: fmt.ext,
          at: Date.now(),
        });
        setHistory(next);
        window.setTimeout(() => setDlState("idle"), 2000);
      }, 1400);
    } catch (e) {
      window.clearInterval(timer);
      setDlState("error");
      toast.error(e instanceof Error ? e.message : "Download failed");
    }
  };

  const filteredHistory = useMemo(() => {
    if (!search) return history;
    const q = search.toLowerCase();
    return history.filter(
      (h) => h.title.toLowerCase().includes(q) || h.uploader.toLowerCase().includes(q),
    );
  }, [history, search]);

  const videoFormats = info?.formats.filter((f) => f.type === "video") ?? [];
  const audioFormats = info?.formats.filter((f) => f.type === "audio") ?? [];

  return (
    <div>
      {/* URL bar */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          const text = e.dataTransfer.getData("text");
          if (text) {
            setUrl(text);
            handleFetch(text);
          }
        }}
        className={cn(
          "glass relative mx-auto max-w-3xl rounded-3xl p-2 shadow-card transition-all",
          dragOver && "ring-2 ring-primary/60",
        )}
      >
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <FiLink className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              ref={inputRef}
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleFetch()}
              placeholder="Paste a video URL from YouTube, TikTok, X, Vimeo…"
              className="w-full rounded-2xl bg-transparent py-4 pl-11 pr-3 text-base outline-none placeholder:text-muted-foreground"
              aria-label="Video URL"
            />
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePaste}
              className="inline-flex items-center gap-2 rounded-2xl bg-muted px-4 py-3 text-sm font-medium text-foreground transition-all hover:bg-muted/70"
            >
              <FiClipboard className="h-4 w-4" /> Paste
            </button>
            <button
              onClick={() => handleFetch()}
              disabled={loading}
              className="inline-flex items-center gap-2 rounded-2xl gradient-primary px-5 py-3 text-sm font-semibold text-white shadow-glow transition-all hover:brightness-110 active:scale-[0.98] disabled:opacity-60"
            >
              <FiDownload className="h-4 w-4" />
              {loading ? "Fetching…" : "Download"}
            </button>
          </div>
        </div>
      </div>

      {!isApiConfigured() && (
        <div className="mx-auto mt-4 max-w-3xl rounded-2xl border border-accent/40 bg-accent/10 px-4 py-3 text-sm text-accent-foreground">
          <p className="text-foreground/90">
            <span className="font-semibold text-accent">Heads up:</span> no backend is configured yet.
            Set <code className="rounded bg-black/30 px-1.5 py-0.5 font-mono text-xs">VITE_API_URL</code> to
            your yt-dlp server URL (see <code className="rounded bg-black/30 px-1.5 py-0.5 font-mono text-xs">/server</code> in the repo).
          </p>
        </div>
      )}

      {/* Error */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            className="mx-auto mt-4 flex max-w-3xl items-start gap-3 rounded-2xl border border-destructive/40 bg-destructive/10 p-4 text-sm"
          >
            <FiAlertCircle className="mt-0.5 h-5 w-5 text-destructive" />
            <p className="text-foreground/90">{error}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Loading skeleton */}
      <AnimatePresence>
        {loading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="mx-auto mt-6 max-w-3xl overflow-hidden rounded-3xl glass p-4"
          >
            <div className="flex gap-4">
              <div className="h-32 w-56 shrink-0 rounded-2xl bg-muted animate-shimmer" />
              <div className="flex-1 space-y-3 py-2">
                <div className="h-5 w-3/4 rounded bg-muted animate-shimmer" />
                <div className="h-4 w-1/2 rounded bg-muted animate-shimmer" />
                <div className="h-4 w-1/3 rounded bg-muted animate-shimmer" />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Video info + formats */}
      <AnimatePresence>
        {info && !loading && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="mx-auto mt-6 max-w-3xl overflow-hidden rounded-3xl glass shadow-card"
          >
            <div className="flex flex-col gap-4 p-4 sm:flex-row">
              <div className="relative aspect-video overflow-hidden rounded-2xl sm:w-64">
                <img
                  src={info.thumbnail}
                  alt={info.title}
                  className="h-full w-full object-cover"
                  loading="lazy"
                />
                <div className="absolute inset-0 grid place-items-center bg-black/20 opacity-0 transition-opacity hover:opacity-100">
                  <FiPlay className="h-10 w-10 text-white drop-shadow" />
                </div>
                <span className="absolute bottom-2 right-2 rounded-md bg-black/70 px-2 py-0.5 text-xs font-medium text-white">
                  {formatDuration(info.duration)}
                </span>
              </div>
              <div className="flex-1 py-1">
                <h3 className="line-clamp-2 font-display text-lg font-semibold leading-snug">
                  {info.title}
                </h3>
                <p className="mt-1 text-sm text-muted-foreground">{info.uploader}</p>
                <div className="mt-3 flex items-center gap-2">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(info.webpage_url);
                      toast.success("Link copied");
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-muted px-2.5 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
                  >
                    <FiCopy className="h-3.5 w-3.5" /> Copy link
                  </button>
                </div>
              </div>
            </div>

            <div className="border-t border-border/60 p-4">
              {videoFormats.length > 0 && (
                <FormatGroup
                  icon={<FiVideo className="h-4 w-4" />}
                  label="Video"
                  formats={videoFormats}
                  selected={selected}
                  onSelect={setSelected}
                />
              )}
              {audioFormats.length > 0 && (
                <div className="mt-4">
                  <FormatGroup
                    icon={<FiMusic className="h-4 w-4" />}
                    label="Audio"
                    formats={audioFormats}
                    selected={selected}
                    onSelect={setSelected}
                  />
                </div>
              )}

              {/* Progress */}
              <AnimatePresence>
                {dlState !== "idle" && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-5 overflow-hidden"
                  >
                    <div className="rounded-2xl bg-muted/60 p-4">
                      <div className="mb-2 flex items-center justify-between text-sm">
                        <span className="font-medium">
                          {dlState === "processing" && "Processing…"}
                          {dlState === "done" && (
                            <span className="inline-flex items-center gap-1.5 text-success">
                              <FiCheck className="h-4 w-4" /> Ready
                            </span>
                          )}
                          {dlState === "error" && (
                            <span className="text-destructive">Failed</span>
                          )}
                        </span>
                        <span className="tabular-nums text-muted-foreground">
                          {Math.round(progress)}%
                        </span>
                      </div>
                      <div className="h-2 overflow-hidden rounded-full bg-background/60">
                        <motion.div
                          className={cn(
                            "h-full rounded-full",
                            dlState === "error" ? "bg-destructive" : "gradient-primary",
                          )}
                          initial={{ width: 0 }}
                          animate={{ width: `${progress}%` }}
                          transition={{ ease: "easeOut" }}
                        />
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="mt-5 flex justify-end">
                <button
                  onClick={startDownload}
                  disabled={!selected || dlState === "processing"}
                  className="inline-flex items-center gap-2 rounded-2xl gradient-primary px-5 py-3 text-sm font-semibold text-white shadow-glow transition-all hover:brightness-110 active:scale-[0.98] disabled:opacity-60"
                >
                  <FiDownload className="h-4 w-4" /> Start download
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* History */}
      {history.length > 0 && (
        <section className="mx-auto mt-16 max-w-4xl px-1">
          <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h2 className="font-display text-xl font-semibold">Recent downloads</h2>
              <p className="text-sm text-muted-foreground">
                Stored only in your browser. Nothing leaves your device.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <FiSearch className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search history"
                  className="w-56 rounded-xl bg-muted/60 py-2 pl-9 pr-3 text-sm outline-none focus:ring-2 focus:ring-primary/40"
                />
              </div>
              <button
                onClick={() => {
                  clearHistory();
                  setHistory([]);
                  toast.success("History cleared");
                }}
                className="inline-flex items-center gap-1.5 rounded-xl bg-muted/60 px-3 py-2 text-sm text-muted-foreground transition-colors hover:text-destructive"
              >
                <FiTrash2 className="h-4 w-4" /> Clear
              </button>
            </div>
          </div>
          <ul className="grid gap-3 sm:grid-cols-2">
            {filteredHistory.map((h) => (
              <motion.li
                key={h.id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                className="glass flex items-center gap-3 rounded-2xl p-2 pr-3"
              >
                <img
                  src={h.thumbnail}
                  alt=""
                  className="h-16 w-24 shrink-0 rounded-xl object-cover"
                  loading="lazy"
                />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{h.title}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {h.uploader} · {h.quality} · {h.ext.toUpperCase()}
                  </p>
                </div>
                <button
                  onClick={() => setHistory(toggleFavorite(h.id))}
                  aria-label="Favorite"
                  className={cn(
                    "grid h-8 w-8 place-items-center rounded-lg transition-colors",
                    h.favorite ? "text-accent" : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  <FiStar className={cn("h-4 w-4", h.favorite && "fill-current")} />
                </button>
                <button
                  onClick={() => setHistory(removeFromHistory(h.id))}
                  aria-label="Remove"
                  className="grid h-8 w-8 place-items-center rounded-lg text-muted-foreground transition-colors hover:text-destructive"
                >
                  <FiTrash2 className="h-4 w-4" />
                </button>
              </motion.li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}

function FormatGroup({
  icon,
  label,
  formats,
  selected,
  onSelect,
}: {
  icon: React.ReactNode;
  label: string;
  formats: VideoFormat[];
  selected: string | null;
  onSelect: (id: string) => void;
}) {
  return (
    <div>
      <div className="mb-2 flex items-center gap-2 text-sm font-medium text-muted-foreground">
        {icon}
        <span>{label}</span>
      </div>
      <div className="flex flex-wrap gap-2">
        {formats.map((f) => {
          const active = selected === f.format_id;
          return (
            <button
              key={f.format_id}
              onClick={() => onSelect(f.format_id)}
              className={cn(
                "group rounded-xl border px-3 py-2 text-left text-sm transition-all",
                active
                  ? "border-primary bg-primary/15 text-foreground shadow-glow"
                  : "border-border/70 bg-muted/40 text-muted-foreground hover:border-primary/50 hover:text-foreground",
              )}
            >
              <div className="flex items-center gap-2">
                <span className="font-semibold">{f.quality}</span>
                <span className="text-xs uppercase text-muted-foreground">{f.ext}</span>
              </div>
              {f.filesize && (
                <div className="mt-0.5 text-xs text-muted-foreground">{formatBytes(f.filesize)}</div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
