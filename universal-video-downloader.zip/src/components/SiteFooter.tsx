import { FiGithub } from "react-icons/fi";

export function SiteFooter() {
  return (
    <footer className="border-t border-border/60 mt-24">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 px-4 py-8 text-sm text-muted-foreground sm:flex-row sm:justify-between sm:px-6">
        <p>© {new Date().getFullYear()} Universal Downloader. All rights reserved.</p>
        <div className="flex items-center gap-5">
          <a href="/faq" className="hover:text-foreground transition-colors">FAQ</a>
          <a href="#" className="hover:text-foreground transition-colors">Privacy</a>
          <a href="#" className="hover:text-foreground transition-colors">Terms</a>
          <a href="#" className="hover:text-foreground transition-colors">Contact</a>
          <a href="https://github.com" target="_blank" rel="noreferrer" className="hover:text-foreground transition-colors" aria-label="GitHub">
            <FiGithub className="h-4 w-4" />
          </a>
        </div>
      </div>
    </footer>
  );
}
