import { motion } from "framer-motion";

export function BackgroundBlobs() {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
      <div className="absolute -top-32 -left-24 h-[420px] w-[420px] rounded-full bg-primary/30 blur-3xl animate-blob" />
      <div
        className="absolute top-40 -right-24 h-[380px] w-[380px] rounded-full bg-secondary/30 blur-3xl animate-blob"
        style={{ animationDelay: "-4s" }}
      />
      <div
        className="absolute top-[520px] left-1/3 h-[360px] w-[360px] rounded-full bg-accent/20 blur-3xl animate-blob"
        style={{ animationDelay: "-8s" }}
      />
      <motion.div
        aria-hidden
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.2 }}
        className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_transparent_40%,_var(--color-background)_80%)]"
      />
    </div>
  );
}
